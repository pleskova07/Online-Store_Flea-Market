package com.example.ServerVPleskova21.dto;

import java.util.List;

public class OrderRequest {
    public String customerName;
    public String contact;
    public String delivery;
    public String comment;
    public List<Item> items;

    public static class Item {
        public Long productId;
        public String title;
        public Double price;
        public Integer qty;
    }
}