package com.example.ServerVPleskova21;

import com.example.ServerVPleskova21.dto.LoginRequest;
import com.example.ServerVPleskova21.dto.RegisterRequest;
import com.example.ServerVPleskova21.dto.UserResponse;
import com.example.ServerVPleskova21.repo.UserRepository;
import com.example.ServerVPleskova21.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService auth;
    private final UserRepository users;

    public AuthController(AuthService auth, UserRepository users) {
        this.auth = auth;
        this.users = users;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        try {
            Long id = auth.register(req);
            Map<String, Object> body = new HashMap<>();
            body.put("id", id);
            body.put("message", "Аккаунт создан");
            return ResponseEntity.ok(body);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        try {
            String token = auth.login(req);
            Map<String, Object> u = users.findByUsername(req.username);
            Map<String, Object> body = new HashMap<>();
            body.put("token", token);
            body.put("user", toResponse(u));
            return ResponseEntity.ok(body);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(401).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        auth.logout(token);
        return ResponseEntity.ok(Map.of("message", "Вы вышли"));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(value = "X-Auth-Token", required = false) String token) {
        Long id = auth.userIdByToken(token);
        if (id == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        return ResponseEntity.ok(toResponse(users.findById(id)));
    }

    private UserResponse toResponse(Map<String, Object> u) {
        if (u == null) return null;
        UserResponse r = new UserResponse();
        r.id = ((Number) u.get("id")).longValue();
        r.surname = (String) u.get("surname");
        r.name = (String) u.get("name");
        r.patronymic = (String) u.get("patronymic");
        r.username = (String) u.get("username");
        r.phone = (String) u.get("phone");
        r.email = (String) u.get("email");
        r.birthday = (LocalDate) u.get("birthday");
        return r;
    }
}