package com.example.ServerVPleskova21.repo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbc;

    public UserRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private final RowMapper<Map<String, Object>> MAPPER = (rs, i) -> {
        var m = new java.util.HashMap<String, Object>();
        m.put("id", rs.getLong("id"));
        m.put("surname", rs.getString("surname"));
        m.put("name", rs.getString("name"));
        m.put("patronymic", rs.getString("patronymic"));
        m.put("username", rs.getString("username"));
        m.put("password_hash", rs.getString("password_hash"));
        m.put("phone", rs.getString("phone"));
        m.put("email", rs.getString("email"));
        var d = rs.getDate("birthday");
        m.put("birthday", d == null ? null : d.toLocalDate());
        return m;
    };

    public boolean existsByUsername(String username) {
        Integer n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM users WHERE username = ?",
                Integer.class, username);
        return n != null && n > 0;
    }

    public boolean existsByEmail(String email) {
        Integer n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM users WHERE email = ?",
                Integer.class, email);
        return n != null && n > 0;
    }

    public Long create(String surname, String name, String patronymic,
                       String username, String passwordHash,
                       String phone, String email, LocalDate birthday) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users (surname, name, patronymic, username, password_hash, phone, email, birthday) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, surname);
            ps.setString(2, name);
            ps.setString(3, patronymic);
            ps.setString(4, username);
            ps.setString(5, passwordHash);
            ps.setString(6, phone);
            ps.setString(7, email);
            ps.setDate(8, java.sql.Date.valueOf(birthday));
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key == null ? null : key.longValue();
    }

    public Map<String, Object> findByUsername(String username) {
        List<Map<String, Object>> list = jdbc.query(
                "SELECT * FROM users WHERE username = ?", MAPPER, username);
        return list.isEmpty() ? null : list.get(0);
    }

    public Map<String, Object> findById(Long id) {
        List<Map<String, Object>> list = jdbc.query(
                "SELECT * FROM users WHERE id = ?", MAPPER, id);
        return list.isEmpty() ? null : list.get(0);
    }
}