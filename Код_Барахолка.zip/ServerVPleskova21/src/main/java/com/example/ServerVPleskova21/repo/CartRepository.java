package com.example.ServerVPleskova21.repo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class CartRepository {

    private final JdbcTemplate jdbc;

    public CartRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void add(Long userId, Long productId, int qty) {
        jdbc.update(
                "INSERT INTO cart_items (user_id, product_id, qty) VALUES (?, ?, ?) " +
                        "ON DUPLICATE KEY UPDATE qty = qty + VALUES(qty)",
                userId, productId, qty);
    }

    public void setQty(Long userId, Long productId, int qty) {
        if (qty <= 0) {
            jdbc.update("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?",
                    userId, productId);
        } else {
            jdbc.update("UPDATE cart_items SET qty = ? WHERE user_id = ? AND product_id = ?",
                    qty, userId, productId);
        }
    }

    public void remove(Long userId, Long productId) {
        jdbc.update("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?",
                userId, productId);
    }

    public List<Map<String, Object>> listByUser(Long userId) {
        return jdbc.queryForList(
                "SELECT product_id, qty FROM cart_items WHERE user_id = ? ORDER BY added_at DESC",
                userId);
    }

    public void clear(Long userId) {
        jdbc.update("DELETE FROM cart_items WHERE user_id = ?", userId);
    }
}