package com.example.ServerVPleskova21;

import com.example.ServerVPleskova21.dto.FavoriteDto;
import com.example.ServerVPleskova21.repo.FavoriteRepository;
import com.example.ServerVPleskova21.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/favorites")
public class FavoritesController {

    private final FavoriteRepository repo;
    private final AuthService auth;

    public FavoritesController(FavoriteRepository repo, AuthService auth) {
        this.repo = repo;
        this.auth = auth;
    }

    @GetMapping
    public ResponseEntity<?> list(@RequestHeader("X-Auth-Token") String token) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @PostMapping
    public ResponseEntity<?> add(@RequestHeader("X-Auth-Token") String token,
                                 @RequestBody FavoriteDto dto) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        repo.add(userId, dto.productId);
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<?> remove(@RequestHeader("X-Auth-Token") String token,
                                    @PathVariable Long productId) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        repo.remove(userId, productId);
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @DeleteMapping
    public ResponseEntity<?> clear(@RequestHeader("X-Auth-Token") String token) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        repo.clear(userId);
        return ResponseEntity.ok(List.of());
    }
}