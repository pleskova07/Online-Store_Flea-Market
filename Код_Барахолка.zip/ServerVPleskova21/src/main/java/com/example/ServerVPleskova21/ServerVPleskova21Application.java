package com.example.ServerVPleskova21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerVPleskova21Application {

	public static void main(String[] args) {
		SpringApplication.run(ServerVPleskova21Application.class, args);
	}

}
