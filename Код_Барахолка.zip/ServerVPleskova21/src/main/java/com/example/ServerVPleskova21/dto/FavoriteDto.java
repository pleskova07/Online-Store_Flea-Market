package com.example.ServerVPleskova21.dto;

public class FavoriteDto {
    public Long productId;
}