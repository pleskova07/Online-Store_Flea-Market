package com.example.ServerVPleskova21;

import com.example.ServerVPleskova21.dto.CartItemDto;
import com.example.ServerVPleskova21.repo.CartRepository;
import com.example.ServerVPleskova21.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartRepository repo;
    private final AuthService auth;

    public CartController(CartRepository repo, AuthService auth) {
        this.repo = repo;
        this.auth = auth;
    }

    @GetMapping
    public ResponseEntity<?> list(@RequestHeader("X-Auth-Token") String token) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @PostMapping
    public ResponseEntity<?> add(@RequestHeader("X-Auth-Token") String token,
                                 @RequestBody CartItemDto dto) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        int qty = dto.qty == null ? 1 : Math.max(1, dto.qty);
        repo.add(userId, dto.productId, qty);
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @PutMapping("/{productId}")
    public ResponseEntity<?> setQty(@RequestHeader("X-Auth-Token") String token,
                                    @PathVariable Long productId,
                                    @RequestBody CartItemDto dto) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        int qty = dto.qty == null ? 1 : dto.qty;
        repo.setQty(userId, productId, qty);
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<?> remove(@RequestHeader("X-Auth-Token") String token,
                                    @PathVariable Long productId) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        repo.remove(userId, productId);
        return ResponseEntity.ok(repo.listByUser(userId));
    }

    @DeleteMapping
    public ResponseEntity<?> clear(@RequestHeader("X-Auth-Token") String token) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));
        repo.clear(userId);
        return ResponseEntity.ok(List.of());
    }
}