package com.example.ServerVPleskova21;

import com.example.ServerVPleskova21.dto.OrderRequest;
import com.example.ServerVPleskova21.repo.CartRepository;
import com.example.ServerVPleskova21.repo.OrderRepository;
import com.example.ServerVPleskova21.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrdersController {

    private final OrderRepository orders;
    private final CartRepository cart;
    private final AuthService auth;

    public OrdersController(OrderRepository orders, CartRepository cart, AuthService auth) {
        this.orders = orders;
        this.cart = cart;
        this.auth = auth;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestHeader("X-Auth-Token") String token,
                                    @RequestBody OrderRequest req) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));

        if (req.items == null || req.items.isEmpty())
            return ResponseEntity.badRequest().body(Map.of("error", "Корзина пуста"));

        double total = 0;
        for (OrderRequest.Item it : req.items) {
            if (it.price == null || it.qty == null) continue;
            total += it.price * it.qty;
        }
        // скидка 5% при заказе от 5000
        if (total >= 5000) total = total - Math.round(total * 0.05);

        Long orderId = orders.createOrder(
                userId,
                req.customerName,
                req.contact,
                req.delivery,
                req.comment,
                total);

        for (OrderRequest.Item it : req.items) {
            orders.addItem(orderId, it.productId, it.title, it.price, it.qty);
        }

        cart.clear(userId);

        return ResponseEntity.ok(Map.of("orderId", orderId, "total", total));
    }

    @GetMapping
    public ResponseEntity<?> myOrders(@RequestHeader("X-Auth-Token") String token) {
        Long userId = auth.userIdByToken(token);
        if (userId == null) return ResponseEntity.status(401).body(Map.of("error", "Не авторизован"));

        List<Map<String, Object>> list = orders.listOrdersByUser(userId);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<String, Object> o : list) {
            Map<String, Object> r = new HashMap<>(o);
            r.put("items", orders.listItems(((Number) o.get("id")).longValue()));
            result.add(r);
        }
        return ResponseEntity.ok(result);
    }
}