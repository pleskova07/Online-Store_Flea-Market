package com.example.ServerVPleskova21.repo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FavoriteRepository {

    private final JdbcTemplate jdbc;

    public FavoriteRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void add(Long userId, Long productId) {
        jdbc.update(
                "INSERT IGNORE INTO favorites (user_id, product_id) VALUES (?, ?)",
                userId, productId);
    }

    public void remove(Long userId, Long productId) {
        jdbc.update("DELETE FROM favorites WHERE user_id = ? AND product_id = ?",
                userId, productId);
    }

    public List<Long> listByUser(Long userId) {
        return jdbc.queryForList(
                "SELECT product_id FROM favorites WHERE user_id = ? ORDER BY added_at DESC",
                Long.class, userId);
    }

    public void clear(Long userId) {
        jdbc.update("DELETE FROM favorites WHERE user_id = ?", userId);
    }
}