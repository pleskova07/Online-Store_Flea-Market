package com.example.ServerVPleskova21.dto;

import java.time.LocalDate;

public class UserResponse {
    public Long id;
    public String surname;
    public String name;
    public String patronymic;
    public String username;
    public String phone;
    public String email;
    public LocalDate birthday;
}