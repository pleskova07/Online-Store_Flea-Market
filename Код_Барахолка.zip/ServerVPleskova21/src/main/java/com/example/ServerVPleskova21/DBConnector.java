/*package com.example.ServerVPleskova21;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.sql.*;

@Configuration
public class DBConnector {
@Bean
public DataSource getDataSource() {
    return DataSourceBuilder.create()
            .driverClassName("com.mysql.cj.jdbc.Driver")
            .url("jdbc:mysql://127.0.0.1:3306/demo1")
            .username("root")
            .password("1234")
            .build();
}

}
*/