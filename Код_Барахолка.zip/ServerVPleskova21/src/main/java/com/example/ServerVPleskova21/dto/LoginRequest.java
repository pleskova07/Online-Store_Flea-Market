package com.example.ServerVPleskova21.dto;

public class LoginRequest {
    public String username;
    public String password;
}