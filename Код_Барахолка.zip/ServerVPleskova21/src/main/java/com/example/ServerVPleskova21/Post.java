/*package com.example.ServerVPleskova21;

public record Post(
        String description,
        String imageUrl
) {
}
*/