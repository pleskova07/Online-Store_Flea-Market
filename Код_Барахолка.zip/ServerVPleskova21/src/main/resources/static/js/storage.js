/* =============================================================
   Универсальное хранилище: сервер (если залогинен) или localStorage
   ============================================================= */

(function (global) {
  const API = '/api';
  const CART_LS = 'cartItems';
  const FAV_LS  = 'favItems';

  function getToken() {
    return localStorage.getItem('authToken');
  }

  function isAuthed() {
    return !!getToken();
  }

  /* ---------- Корзина ---------- */
  async function getCart() {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/cart`, {
          headers: { 'X-Auth-Token': getToken() }
        });
        if (r.ok) {
          const data = await r.json();
          return Array.isArray(data) ? data.map(x => ({
            id: Number(x.product_id ?? x.productId ?? x.id),
            qty: Number(x.qty || 1)
          })) : [];
        }
      } catch (e) { /* ignore */ }
    }
    // гость — localStorage
    try {
      return JSON.parse(localStorage.getItem(CART_LS) || '[]')
        .map(it => ({ id: Number(it.id), qty: Math.max(1, Number(it.qty) || 1) }));
    } catch { return []; }
  }

  async function addToCart(productId, qty = 1) {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/cart`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': getToken()
          },
          body: JSON.stringify({ productId: Number(productId), qty })
        });
        return r.ok;
      } catch { return false; }
    }
    // гость
    const items = await getCart();
    const found = items.find(x => x.id === Number(productId));
    if (found) found.qty += qty;
    else items.push({ id: Number(productId), qty });
    localStorage.setItem(CART_LS, JSON.stringify(items));
    return true;
  }

  async function setCartQty(productId, qty) {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/cart/${productId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': getToken()
          },
          body: JSON.stringify({ qty })
        });
        return r.ok;
      } catch { return false; }
    }
    let items = await getCart();
    const it = items.find(x => x.id === Number(productId));
    if (!it) return false;
    if (qty <= 0) items = items.filter(x => x.id !== Number(productId));
    else it.qty = Math.max(1, Math.min(99, qty));
    localStorage.setItem(CART_LS, JSON.stringify(items));
    return true;
  }

  async function removeFromCart(productId) {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/cart/${productId}`, {
          method: 'DELETE',
          headers: { 'X-Auth-Token': getToken() }
        });
        return r.ok;
      } catch { return false; }
    }
    const items = (await getCart()).filter(x => x.id !== Number(productId));
    localStorage.setItem(CART_LS, JSON.stringify(items));
    return true;
  }

  async function clearCart() {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/cart`, {
          method: 'DELETE',
          headers: { 'X-Auth-Token': getToken() }
        });
        return r.ok;
      } catch { return false; }
    }
    localStorage.removeItem(CART_LS);
    return true;
  }

  /* ---------- Избранное ---------- */
  async function getFavorites() {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/favorites`, {
          headers: { 'X-Auth-Token': getToken() }
        });
        if (r.ok) {
          const data = await r.json();
          return Array.isArray(data) ? data.map(x => Number(x)) : [];
        }
      } catch (e) { /* ignore */ }
    }
    try {
      return JSON.parse(localStorage.getItem(FAV_LS) || '[]').map(Number);
    } catch { return []; }
  }

  async function addToFavorites(productId) {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/favorites`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': getToken()
          },
          body: JSON.stringify({ productId: Number(productId) })
        });
        return r.ok;
      } catch { return false; }
    }
    const ids = await getFavorites();
    if (!ids.includes(Number(productId))) ids.push(Number(productId));
    localStorage.setItem(FAV_LS, JSON.stringify(ids));
    return true;
  }

  async function removeFromFavorites(productId) {
    if (isAuthed()) {
      try {
        const r = await fetch(`${API}/favorites/${productId}`, {
          method: 'DELETE',
          headers: { 'X-Auth-Token': getToken() }
        });
        return r.ok;
      } catch { return false; }
    }
    const ids = (await getFavorites()).filter(x => x !== Number(productId));
    localStorage.setItem(FAV_LS, JSON.stringify(ids));
    return true;
  }

  async function isFavorite(productId) {
    const ids = await getFavorites();
    return ids.includes(Number(productId));
  }

  /* ---------- Счётчики для шапки ---------- */
  async function updateHeaderCounts() {
    try {
      const [cart, fav] = await Promise.all([getCart(), getFavorites()]);
      const cartTotal = cart.reduce((s, it) => s + (it.qty || 0), 0);
      const cartEl = document.querySelector('.header__cart-count');
      const favEl  = document.querySelector('.header__fav-count');
      if (cartEl) cartEl.textContent = cartTotal;
      if (favEl)  favEl.textContent  = fav.length;
    } catch (e) { /* ignore */ }
  }

  /* ---------- Перенос гостевых данных в БД при входе ---------- */
  async function mergeGuestDataToServer() {
    if (!isAuthed()) return;

    // корзина
    let guestCart = [];
    try {
      guestCart = JSON.parse(localStorage.getItem(CART_LS) || '[]');
    } catch (e) {}
    for (const it of guestCart) {
      try {
        await fetch(`${API}/cart`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': getToken()
          },
          body: JSON.stringify({ productId: Number(it.id), qty: Math.max(1, Number(it.qty) || 1) })
        });
      } catch (e) { /* ignore */ }
    }
    if (guestCart.length) localStorage.removeItem(CART_LS);

    // избранное
    let guestFav = [];
    try {
      guestFav = JSON.parse(localStorage.getItem(FAV_LS) || '[]');
    } catch (e) {}
    for (const id of guestFav) {
      try {
        await fetch(`${API}/favorites`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': getToken()
          },
          body: JSON.stringify({ productId: Number(id) })
        });
      } catch (e) { /* ignore */ }
    }
    if (guestFav.length) localStorage.removeItem(FAV_LS);
  }

  /* ---------- Экспорт ---------- */
  global.Store = {
    isAuthed,
    getToken,

    getCart, addToCart, setCartQty, removeFromCart, clearCart,
    getFavorites, addToFavorites, removeFromFavorites, isFavorite,

    updateHeaderCounts,
    mergeGuestDataToServer
  };
})(window);