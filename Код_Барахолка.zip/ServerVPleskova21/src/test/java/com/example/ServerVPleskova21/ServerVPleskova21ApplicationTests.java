package com.example.ServerVPleskova21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerVPleskova21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
