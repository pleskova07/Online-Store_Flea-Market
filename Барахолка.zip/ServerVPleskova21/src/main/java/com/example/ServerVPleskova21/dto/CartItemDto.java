package com.example.ServerVPleskova21.dto;

public class CartItemDto {
    public Long productId;
    public Integer qty;
    public String color;
}