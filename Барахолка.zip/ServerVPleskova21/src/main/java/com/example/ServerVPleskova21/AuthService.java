package com.example.ServerVPleskova21;

import com.example.ServerVPleskova21.dto.LoginRequest;
import com.example.ServerVPleskova21.dto.RegisterRequest;
import com.example.ServerVPleskova21.repo.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class AuthService {

    private final UserRepository users;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    // токен -> userId
    private final Map<String, Long> sessions = new java.util.concurrent.ConcurrentHashMap<>();

    public AuthService(UserRepository users) {
        this.users = users;
    }

    public Long register(RegisterRequest req) {
        if (req.username == null || req.username.isBlank())
            throw new IllegalArgumentException("Логин обязателен");
        if (!req.username.matches("^[A-Za-z0-9_-]{4,20}$"))
            throw new IllegalArgumentException("Логин: 4–20 символов, латиница/цифры/_/-");
        if (users.existsByUsername(req.username))
            throw new IllegalArgumentException("Такой логин уже занят");
        if (req.email == null || !req.email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new IllegalArgumentException("Некорректный email");
        if (users.existsByEmail(req.email))
            throw new IllegalArgumentException("Email уже используется");
        if (req.password == null || req.password.length() < 6)
            throw new IllegalArgumentException("Пароль минимум 6 символов");
        if (req.phone == null || req.phone.isBlank())
            throw new IllegalArgumentException("Телефон обязателен");
        if (req.birthday == null)
            throw new IllegalArgumentException("Дата рождения обязательна");

        String hash = encoder.encode(req.password);
        return users.create(
                req.surname, req.name, req.patronymic,
                req.username, hash,
                req.phone, req.email, req.birthday);
    }

    public String login(LoginRequest req) {
        if (req.username == null || req.password == null)
            throw new IllegalArgumentException("Заполните логин и пароль");

        Map<String, Object> u = users.findByUsername(req.username.trim());
        if (u == null) throw new IllegalArgumentException("Неверный логин или пароль");

        String hash = (String) u.get("password_hash");
        if (!encoder.matches(req.password, hash))
            throw new IllegalArgumentException("Неверный логин или пароль");

        String token = UUID.randomUUID().toString();
        sessions.put(token, ((Number) u.get("id")).longValue());
        return token;
    }

    public Long userIdByToken(String token) {
        if (token == null) return null;
        return sessions.get(token);
    }

    public void logout(String token) {
        if (token != null) sessions.remove(token);
    }
}