package com.example.ServerVPleskova21.repo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

@Repository
public class OrderRepository {

    private final JdbcTemplate jdbc;

    public OrderRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Long createOrder(Long userId, String customerName, String contact,
                            String delivery, String comment, double total) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO orders (user_id, customer_name, contact, delivery, comment, total) " +
                            "VALUES (?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, userId);
            ps.setString(2, customerName);
            ps.setString(3, contact);
            ps.setString(4, delivery);
            ps.setString(5, comment);
            ps.setDouble(6, total);
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key == null ? null : key.longValue();
    }

    public void addItem(Long orderId, Long productId, String title, double price, int qty) {
        jdbc.update(
                "INSERT INTO order_items (order_id, product_id, title, price, qty) VALUES (?, ?, ?, ?, ?)",
                orderId, productId, title, price, qty);
    }

    public List<Map<String, Object>> listOrdersByUser(Long userId) {
        return jdbc.queryForList(
                "SELECT id, total, status, delivery, created_at FROM orders " +
                        "WHERE user_id = ? ORDER BY created_at DESC",
                userId);
    }

    public List<Map<String, Object>> listItems(Long orderId) {
        return jdbc.queryForList(
                "SELECT product_id, title, price, qty FROM order_items WHERE order_id = ?",
                orderId);
    }

    public boolean cancelOrder(Long orderId, Long userId) {
        int rows = jdbc.update(
                "UPDATE orders SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status != 'cancelled'",
                orderId, userId);
        return rows > 0;
    }

}