/* =============================================================
   static/js/products.js
   ============================================================= */

(function (global) {

  /* ---------- Категории ---------- */
  const CATEGORIES = {
    all:         { name: 'Все товары',      icon: '🛍️' },
    accessories: { name: 'Аксессуары',      icon: '🧣' },
    jewelry:     { name: 'Бижутерия',       icon: '💎' },
    notebooks:   { name: 'Блокноты',        icon: '📓' },
    toys:        { name: 'Игрушки',         icon: '🧸' },
    souvenirs:   { name: 'Сувениры',        icon: '🎁' },
    stationery:  { name: 'Канцелярия',      icon: '✏️' },
    boardgames:  { name: 'Настольные игры', icon: '🎲' },
    home:        { name: 'Для дома',        icon: '🏠' },
    photo:       { name: 'Фотоальбомы',     icon: '📷' }
  };

  /* ---------- Характеристики по категориям ---------- */
  const CATEGORY_DETAILS = {
    accessories: {
      desc: 'Прекрасный аксессуар, который дополнит повседневный образ и согреет в прохладные дни.',
      specs: { 'Материал': 'Натуральные волокна', 'Уход': 'Ручная стирка 30°', 'Производство': 'Россия' }
    },
    jewelry: {
      desc: 'Легкое украшение, не тускнеет, подходит для повседневной носки и особых случаев.',
      specs: { 'Материал': 'Латунь, стекло', 'Покрытие': 'Золото 14К', 'Гипоаллергенно': 'Да' }
    },
    notebooks: {
      desc: 'Блокнот с приятной на ощупь обложкой и плотной бумагой. Подойдёт для заметок, планов и скетчей.',
      specs: { 'Формат': 'A5', 'Листы': '160, 80 г/м²', 'Крепление': 'Прошивка' }
    },
    toys: {
      desc: 'Мягкая игрушка из экологичных материалов. Приятная на ощупь, безопасна для детей с 3 лет.',
      specs: { 'Высота': '25 см', 'Наполнитель': 'Холофайбер', 'Возраст': '3+' }
    },
    souvenirs: {
      desc: 'Маленький сувенир, который порадует вас или станет приятным подарком близким.',
      specs: { 'Материал': 'Керамика/дерево', 'Размер': 'до 10 см', 'Упаковка': 'Подарочная' }
    },
    stationery: {
      desc: 'Канцелярский предмет для работы и учёбы. Удобный, долговечный, приятный в использовании.',
      specs: { 'Материал': 'Дерево, текстиль', 'Цвет': 'Натуральный', 'Производство': 'Россия' }
    },
    boardgames: {
      desc: 'Настольная игра для уютных вечеров с семьёй и друзьями. Понятные правила, партия 20–60 минут.',
      specs: { 'Игроков': '2–6', 'Время партии': '20–60 мин', 'Возраст': '6+' }
    },
    home: {
      desc: 'Предмет для дома, который создаёт уют и радует каждый день.',
      specs: { 'Материал': 'Керамика/текстиль', 'Уход': 'Бережный', 'Производство': 'Россия' }
    },
    photo: {
      desc: 'Фотоальбом для хранения тёплых воспоминаний. Плотные страницы, аккуратный переплёт.',
      specs: { 'Формат': '20×20 см', 'Страниц': '40', 'Обложка': 'Твёрдая' }
    }
  };


/*
Пример для товаров
      images: [
           '',
           '',
           '',
           ''],
      colors: [
        { name: '', hex: '' },
        { name: '',  hex: '' },
        { name: '', hex: '' },
        { name: '', hex: '' }
      ] },

      цвета:

      Розовый #E399CF
      Голубой #72CBCB
      Бежевый #d7c6a8
      Коричневый #653A16
      Белый #FFFFFF
      Светло-серый #BFBFBF
      Чёрный #000000
      Бордовый #52131E
      Красный #FF0000
      Тёмно-зелёный #004900
      Оранжевый #FF9500
      Сиреневый #D48FE9
      Зелёный #67E300
      Серый #808080
      Фиолетовый #7109AA
*/

  /* ---------- Товары ---------- */
  const LIST = [
    { id: 1,  title: 'Шарф «Тёплый»', price: 950,  cat: 'accessories', img: 'https://ir.ozone.ru/s3/multimedia-i/6503956278.jpg',
      images: [
          'https://ir.ozone.ru/s3/multimedia-i/6503956278.jpg',
          'https://aimclo.ru/upload/iblock/16c/20201118_aim_0048-1-kopiya.jpg',
          'https://aimclo.ru/upload/iblock/a2b/20201118_aim_0026-1.jpg',
          'https://aimclo.ru/upload/resize_cache/iblock/c9b/1200_1600_1/20220316_aim_clo0260-kopiya.jpg'],
      colors: [
            { name: 'Розовый',  hex: '#E399CF' },
            { name: 'Голубой',  hex: '#72CBCB' },
            { name: 'Бежевый',hex: '#d7c6a8' },
            { name: 'Коричневый',hex: '#653A16' }
      ] },
    { id: 2,  title: 'Сумка «Рогожка»', price: 1800, cat: 'accessories', img: 'https://cs2.livemaster.ru/storage/e3/5a/60373b4cdcda88dfb76307dc43ma--sumki-i-aksessuary-sumka-shopper-iz-rogozhki-belaya-noch-tout.jpg',
      images: [
           'https://cs2.livemaster.ru/storage/e3/5a/60373b4cdcda88dfb76307dc43ma--sumki-i-aksessuary-sumka-shopper-iz-rogozhki-belaya-noch-tout.jpg',
           'https://cdn-yc.100sp.ru/pictures/647553002.webp',
           'https://saray.ru/upload/iblock/975/ftialr9wmi6zq50z5lps8y8k6yijcgwp.jpg',
           'https://ir.ozone.ru/s3/multimedia-u/6388109514.jpg'],
      colors: [
            { name: 'Белый', hex: '#FFFFFF' },
            { name: 'Голубой',  hex: '#72CBCB' },
            { name: 'Светло-серый', hex: '#BFBFBF' },
            { name: 'Розовая', hex: '#E399CF' } ] },
    { id: 3,  title: 'Кошелёк «Кожа»', price: 2100, cat: 'accessories', img: 'https://usmall.ru/image/1588/13/08/2fb0940e4596bd62e2924b69937feecd.jpeg',
      images: [
           'https://usmall.ru/image/1588/13/08/2fb0940e4596bd62e2924b69937feecd.jpeg',
           'https://usmall.ru/image/1588/13/08/5c86149c5b7bf29e4b40588d38567291.jpeg',
           'https://usmall.ru/image/1588/13/08/3eb7d627666166810a477cd5a2888bbc.jpeg',
           'https://usmall.ru/image/1588/13/08/62943da93f3113bccb3eea9724cd7d05.jpeg'] },
    { id: 4,  title: 'Перчатки «Зима»', price: 1200, cat: 'accessories', img: 'https://avatars.mds.yandex.net/i?id=eb0db53ba73ef77ac5dce35de3f69acc_l-5597742-images-thumbs&n=13',
      images: [
            'https://avatars.mds.yandex.net/i?id=eb0db53ba73ef77ac5dce35de3f69acc_l-5597742-images-thumbs&n=13',
            'https://avatars.mds.yandex.net/i?id=e5752a353ca49eb3ab22176b56e2527d_sr-4080268-images-thumbs&n=13',
            'https://avatars.mds.yandex.net/get-mpic/4397502/2a0000019637326f94da1a7f3a900fef1c9e/orig',
            'https://cdn0.youla.io/files/images/360_360/5f/38/5f38f883099a8076fa4fed55-1.jpg'],
      colors: [
        { name: 'Чёрный', hex: '#000000' },
        { name: 'Бордовый',  hex: '#52131E' }
      ]},
    { id: 5,  title: 'Ремень «Классика»', price: 1400, cat: 'accessories', img: 'https://cs5.livemaster.ru/storage/34/6f/5cf880415254444e6cae328fd72i--aksessuary-chernyj-kozhanyj-remen-klassika-s-ruchnoj-proshivk.jpg',
    images: [
            'https://cs5.livemaster.ru/storage/34/6f/5cf880415254444e6cae328fd72i--aksessuary-chernyj-kozhanyj-remen-klassika-s-ruchnoj-proshivk.jpg',
            'https://allpen.ru/components/com_virtuemart/shop_image/product/b3e8f1cefce106eb9fffb9b2112181d4.png',
            'https://img-fotki.yandex.ru/get/16130/236929093.b/0_f076a_a9fe807d_L.jpg',
            'https://cs1.livemaster.ru/storage/49/31/b62b9d17406d63e2f65dabaf1bbu--aksessuary-remen-kozhanyj-muzhskoj-chernyj-klassicheskij-pros.jpg'] },
    { id: 6,  title: 'Шапка «Помпон»', price: 890,  cat: 'accessories', img: 'https://img-edg.joomcdn.net/3eb0870f7020ba67653f0c849d99cba986fd22b9_original.jpeg',
      images: [
            'https://img-edg.joomcdn.net/3eb0870f7020ba67653f0c849d99cba986fd22b9_original.jpeg',
            'https://avatars.mds.yandex.net/i?id=3f72ec9af66f71182cb59de766fc6a9a_l-12569877-images-thumbs&n=13',
            'https://img.joomcdn.net/709de1f97eaa0725615df6505ec41854535b82df_original.jpeg',
            'https://avatars.mds.yandex.net/i?id=7293c8907fb23bb8f2f48261eeaeac66_l-9151370-images-thumbs&n=13'],
      colors: [
        { name: 'Чёрный',    hex: '#000000' },
        { name: 'Розовый',  hex: '#e8a5b5' },
        { name: 'Красный', hex: '#FF0000' },
        { name: 'Белый', hex: '#FFFFFF' }
      ] },
    { id: 7,  title: 'Серьги «Лаванда»', price: 1200, cat: 'jewelry', img: 'https://basket-28.wbbasket.ru/vol5244/part524456/524456273/images/big/1.webp',
     images: [
                'https://basket-28.wbbasket.ru/vol5244/part524456/524456273/images/big/1.webp',
                'https://www.jewel-classic.ru/wp-content/uploads/2025/01/e-6340.jpg',
                'https://basket-44.wbbasket.ru/vol12529/part1252982/1252982517/images/big/1.webp',
                'https://ir.ozone.ru/s3/multimedia-1-1/6921863857.jpg'] },
    { id: 8,  title: 'Брошь «Лист»', price: 890,  cat: 'jewelry', img: 'https://i.pinimg.com/originals/62/78/cc/6278cce3608390e73ceba1f9dc181a8f.jpg',
     images: [
                'https://i.pinimg.com/originals/62/78/cc/6278cce3608390e73ceba1f9dc181a8f.jpg',
                'https://i.pinimg.com/originals/11/09/4d/11094d6df003ec677b92f2289d5930a3.jpg' ]},
    { id: 9,  title: 'Колье «Роса»', price: 1650, cat: 'jewelry', img: 'https://www.click-boutique.ru/upload/iblock/88e/j7w0axb2i3rwpb7hngszcirxbjxwukyv/IMG_9001%20╨║╨╛╨┐╨╕╤П.jpg',
     images: [
                'https://www.click-boutique.ru/upload/iblock/88e/j7w0axb2i3rwpb7hngszcirxbjxwukyv/IMG_9001%20╨║╨╛╨┐╨╕╤П.jpg',
                'https://ir.ozone.ru/s3/multimedia-1-r/12062965383.jpg',
                'https://cs5.livemaster.ru/storage/df/2b/5c08ff10380954a93df7be62f4ro--ukrasheniya-kole-kapelki-rosy-kole-kapli-vody-iz-smoly-ukrash.jpg',
                'https://cs5.livemaster.ru/storage/54/8b/cd2d9bc8b99789d3103188decceo--ukrasheniya-kole-kapelki-rosy-kole-kapli-vody-iz-smoly-ukrash.jpg'] },
    { id: 10, title: 'Браслет «Узел»', price: 720,  cat: 'jewelry', img: 'https://st.aestatic.net/items-img-12/R/B/K/N/1e45efaab0b61ea32be54cfdd51e932f.jpg_960x960.jpg',
     images: [
                'https://st.aestatic.net/items-img-12/R/B/K/N/1e45efaab0b61ea32be54cfdd51e932f.jpg_960x960.jpg',
                'https://st.aestatic.net/items-img-21/R/K/3/H/7a7ea55e26292428ee63ab3d37c4a4a5.jpg_960x960.jpg',
                'https://st.aestatic.net/items-img-19/R/I/L/J/4322ace3a0e3163e7e8dc25eed0f4b5d.jpg_960x960.jpg',
                'https://img-edg.joomcdn.net/6716812abde79ba80623008bfc37e484b33edf09_original.jpeg'] },
    { id: 11, title: 'Кольцо «Луна»', price: 1350, cat: 'jewelry', img: 'https://ae-pic-a1.aliexpress-media.com/kf/S5b8ee764d7ba44f69ef69a6a36e1bbf95.jpg',
     images: [
                'https://ae-pic-a1.aliexpress-media.com/kf/S5b8ee764d7ba44f69ef69a6a36e1bbf95.jpg',
                'https://ae-pic-a1.aliexpress-media.com/kf/Sc79b52a6424b48cea84ba011cf2725ebP.jpg',
                'https://basket-12.wbbasket.ru/vol1720/part172033/172033532/images/big/1.webp',
                'https://ae-pic-a1.aliexpress-media.com/kf/S384a6d245f804249be697212fae7d73f3.jpg']},
    { id: 12, title: 'Серьги «Капли»', price: 980,  cat: 'jewelry', img: 'https://basket-03.wbbasket.ru/vol377/part37706/37706905/images/big/1.webp',
     images: [
                'https://basket-03.wbbasket.ru/vol377/part37706/37706905/images/big/1.webp',
                'https://ae-pic-a1.aliexpress-media.com/kf/S17ff352c37364e39bb3fdf80966155f13.jpg_640x640.jpg',
                'https://ae-pic-a1.aliexpress-media.com/kf/Sa7ce19d5d5c74dafa5e478c73d3cbe61n.jpg',
                'https://ae-pic-a1.aliexpress-media.com/kf/S37f938288e3748d8a3b751e8f1b5b33df.jpg']},
    { id: 13, title: 'Блокнот «Поле»', price: 450,  cat: 'notebooks', img: 'https://storage.vsemayki.ru/images/0/0/944/944920/previews/people_1_notepad_back_white_500.jpg',
     images: [
                 'https://storage.vsemayki.ru/images/0/0/944/944920/previews/people_1_notepad_back_white_500.jpg',
                 'https://catalog-cdn.detmir.st/media/We1xfid8b-zggIO9xKkGKZzd_dU1xQ7kMSdnAAH3uWM=.jpeg',
                 'https://storage.vsemayki.ru/images/0/0/944/944920/previews/people_1_notepad_front_white_500.jpg',
                 'https://3di.ru/content/images/preview/4100206175bfb0f3c7c0a534b66523e8/1000_750/49c3103dab16afda.jpg'] },
    { id: 14, title: 'Дневник садовника', price: 520,  cat: 'notebooks', img: 'https://basket-15.wbbasket.ru/vol2253/part225326/225326141/images/big/1.webp',
          images: [
               'https://basket-15.wbbasket.ru/vol2253/part225326/225326141/images/big/1.webp',
               'https://ir.ozone.ru/s3/multimedia-1-o/c1000/9260539836.jpg',
               'https://basket-20.wbbasket.ru/vol3357/part335766/335766307/images/big/1.webp',
               'https://img.joomcdn.net/1c557bfd3ca64e5a32971c11928abec8a33db124_original.jpeg'],
          colors: [
            { name: 'Тёмно-зелёный', hex: '#004900' },
            { name: 'Чёрный',  hex: '#000000' },
            { name: 'Белый', hex: '#FFFFF'}] },
    { id: 15, title: 'Ежедневник «Кожа»', price: 890,  cat: 'notebooks', img: 'https://avatars.mds.yandex.net/i?id=75fdc9a06e2fc9b00c9aaebe4c8f2c5feacf679a-7017268-images-thumbs&n=13',
          images: [
               'https://avatars.mds.yandex.net/i?id=75fdc9a06e2fc9b00c9aaebe4c8f2c5feacf679a-7017268-images-thumbs&n=13',
               'https://stihi.ru/pics/2020/02/21/3911.jpg',
               'https://3259404.ru/upload/iblock/669/669391306c3c8521102e574d1bb54102.jpg',
               'https://avatars.mds.yandex.net/get-mpic/5332938/img_id1292146554165703171.png/orig'] },
    { id: 16, title: 'Крафт-Блокнот «Лес»', price: 380,  cat: 'notebooks', img: 'https://img.centrmag.ru/catalog/ev61_130826.jpg',
          images: [
               'https://img.centrmag.ru/catalog/ev61_130826.jpg',
               'https://img.centrmag.ru/catalog/ev62_130826.jpg',
               'https://img.centrmag.ru/catalog/ev63_130826.jpg',
               'https://img.centrmag.ru/catalog/ev64_130826.jpg'] },
    { id: 17, title: 'Скетчбук «Космос»', price: 690,  cat: 'notebooks', img: 'https://ekt-basket-cdn-15.geobasket.ru/vol16278/part1627818/1627818536/images/big/1.webp?picsUpdate=0',
          images: [
               'https://ekt-basket-cdn-15.geobasket.ru/vol16278/part1627818/1627818536/images/big/1.webp?picsUpdate=0',
               'https://ekt-basket-cdn-15.geobasket.ru/vol16278/part1627818/1627818536/images/big/5.webp?picsUpdate=0',
               'https://ekt-basket-cdn-15.geobasket.ru/vol16278/part1627818/1627818536/images/big/6.webp?picsUpdate=0',
               'https://ekt-basket-cdn-15.geobasket.ru/vol16278/part1627818/1627818536/images/big/4.webp?picsUpdate=0'] },
    { id: 18, title: 'Плюшевый ёж', price: 1300, cat: 'toys', img: 'https://avatars.mds.yandex.net/get-mpic/21319520/pice753d0b8c7e8015ee46d941f6b2d68c0/orig',
      images: [
           'https://avatars.mds.yandex.net/get-mpic/21319520/pice753d0b8c7e8015ee46d941f6b2d68c0/orig',
           'https://ir.ozone.ru/s3/multimedia-1-d/wc1000/13281915001.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-t/8952886217.jpg',
           'https://basket-36.wbbasket.ru/vol7908/part790850/790850506/images/big/1.webp'] },
    { id: 19, title: 'Зайка «Пух»', price: 1100, cat: 'toys', img: 'https://basket-28.wbbasket.ru/vol5273/part527312/527312123/images/big/1.webp',
      images: [
           'https://basket-28.wbbasket.ru/vol5273/part527312/527312123/images/big/1.webp',
           'https://basket-27.wbbasket.ru/vol5036/part503677/503677912/images/big/1.webp',
           'https://avatars.mds.yandex.net/i?id=48906ecba157b3d19af2f54bd8687e5c52899cdb-10353822-images-thumbs&n=13',
           'https://avatars.mds.yandex.net/i?id=e3a4865539f7e4f841581404c3f1e496d48f0b54-6356264-images-thumbs&n=13'],
      colors: [
        { name: 'Сиреневый', hex: '#D48FE9' },
        { name: 'Светло-серый',  hex: '#BFBFBF' },
        { name: 'Розовый', hex: '#E399CF' },
        { name: 'Оранджевый', hex: '#FF9500' }
      ] },
    { id: 20, title: 'Мишка «Тёпа»', price: 1450, cat: 'toys', img: 'https://ir.ozone.ru/s3/multimedia-1-3/wc1000/14821482135.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-1-3/wc1000/14821482135.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-w/wc1000/15453939416.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-u/wc1000/15453939414.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-4/wc1000/15453939424.jpg'] },
    { id: 21, title: 'Кот «Мурзик»', price: 990,  cat: 'toys', img: 'https://goods-photos.static1-sima-land.com/items/7761882/1/1600.jpg?v=1721110873',
      images: [
           'https://goods-photos.static1-sima-land.com/items/7761882/1/1600.jpg?v=1721110873',
           'https://goods-photos.static1-sima-land.com/items/7761882/2/1600.jpg?v=1721110880',
           'https://goods-photos.static1-sima-land.com/items/7761882/5/1600.jpg?v=1721110896',
           'https://goods-photos.static1-sima-land.com/items/7761882/1/1600.jpg?v=1721110873'] },
    { id: 22, title: 'Сова «Зима»', price: 1250, cat: 'toys', img: 'https://avatars.mds.yandex.net/i?id=dff7f6a867a7f146ad06c3be5d2c04efa88fcc52-5602641-images-thumbs&n=13',
      images: [
           'https://avatars.mds.yandex.net/i?id=dff7f6a867a7f146ad06c3be5d2c04efa88fcc52-5602641-images-thumbs&n=13',
           'https://avatars.mds.yandex.net/i?id=fe29db43bacb570c72d722211110e72e902a458e-16340208-images-thumbs&n=13',
           'https://img-edg.joomcdn.net/353db9d221935e6fb3c4b68d4303d4c25af7e104_original.jpeg',
           'https://avatars.mds.yandex.net/i?id=15660ce79ca9a427fe732ab05713ccd361fac667-9065839-images-thumbs&n=13'] },
    { id: 23, title: 'Пингвин «Лёд»', price: 1150, cat: 'toys', img: 'https://avatars.mds.yandex.net/i?id=6237c22acd5ce661e98a8b4e146fb499_l-5175116-images-thumbs&n=13',
      images: [
           'https://avatars.mds.yandex.net/i?id=6237c22acd5ce661e98a8b4e146fb499_l-5175116-images-thumbs&n=13',
           'https://avatars.mds.yandex.net/i?id=033171b5f40e44239d47258f8b32408f673fe14b-5448488-images-thumbs&n=13',
           'https://avatars.mds.yandex.net/i?id=2aef132aad4613f55a77a3f1b27affde_l-5597410-images-thumbs&n=13',
           'https://i.pinimg.com/736x/1f/e7/75/1fe775e5431968a01f4d01086541968a.jpg'] },
    { id: 24, title: 'Магнит «Кот»', price: 250,  cat: 'souvenirs', img: 'https://ir.ozone.ru/s3/multimedia-2/wc1000/6568073702.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-2/wc1000/6568073702.jpg',
           'https://ir.ozone.ru/s3/multimedia-u/6568072974.jpg',
           'https://avatars.mds.yandex.net/i?id=314c00bd3634887ae98408c1f0923b250e21a6fa-5352984-images-thumbs&n=13',
           'https://ir.ozone.ru/s3/multimedia-7/wc1000/6493330111.jpg'],
      colors: [
        { name: 'Серый', hex: '#808080' },
        { name: 'Зелёный',  hex: '#67E300' },
        { name: 'Оранжевый', hex: '#FF9500' },
        { name: 'Чёрный', hex: '#000000' },
        { name: 'Белый', hex: '#FFFFFF' },
        { name: 'Коричневый', hex: '#653A16' },
        { name: 'Голубой', hex: '#72CBCB' }
      ] },
    { id: 25, title: 'Открытка «Люблю»', price: 120,  cat: 'souvenirs', img: 'https://gingerjoys.ru/wp-content/uploads/2024/11/20241113-img_1111-768x1024.jpg',
      images: [
           'https://gingerjoys.ru/wp-content/uploads/2024/11/20241113-img_1111-768x1024.jpg',
           'https://gingerjoys.ru/wp-content/uploads/2024/11/20241113-img_1112-scaled.jpg'] },
    { id: 26, title: 'Брелок «Туз»', price: 320,  cat: 'souvenirs', img: 'https://ir.ozone.ru/s3/multimedia-9/c1000/6154328337.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-1-e/c1000/12348186854.jpg',
           'https://cdn1.ozone.ru/s3/multimedia-1-1/7658543089.jpg',
           'https://avatars.mds.yandex.net/i?id=bfd15185af4c8084b7f1feade14577e9ac568a32-9227708-images-thumbs&n=13',
           '/img/Karta.png'],
      colors: [
        { name: 'Пики', hex: '#000000' },
        { name: 'Черви',  hex: '#FF0000' },
        { name: 'Трефы', hex: '#808080' },
        { name: 'Бубны', hex: '#52131E' }
      ] },
    { id: 27, title: 'Брелок «Лиса»', price: 180,  cat: 'souvenirs', img: 'https://basket-10.wbbasket.ru/vol1591/part159171/159171037/images/big/1.webp',
          images: [
               'https://basket-10.wbbasket.ru/vol1591/part159171/159171037/images/big/1.webp',
               'https://ekt-basket-cdn-16.geobasket.ru/vol1591/part159171/159171037/images/big/3.webp?picsUpdate=0',
               'https://ekt-basket-cdn-16.geobasket.ru/vol1591/part159171/159171037/images/big/2.webp?picsUpdate=0',
               'https://ekt-basket-cdn-16.geobasket.ru/vol1591/part159171/159171037/images/big/5.webp?picsUpdate=0'] },
    { id: 28, title: 'Керамический кот', price: 780,  cat: 'souvenirs', img: 'https://www.ipm.ru/upload/iblock/pze/pze38zguin4fhcwjgx2jg0t476wrg9ki.webp',
      images: [
           'https://www.ipm.ru/upload/iblock/pze/pze38zguin4fhcwjgx2jg0t476wrg9ki.webp',
           'https://www.ipm.ru/upload/iblock/ww4/ww4yncuxjv41l2e1bypektsvupb6h49j.webp',
           'https://www.ipm.ru/upload/iblock/a4o/a4o9drp40vdh06kbmk11mk08y51y9yxz.webp',
           'https://www.ipm.ru/upload/iblock/8pb/8pb87mrb7bke4mnj2rem988p81cd84wg.webp'] },
    { id: 29, title: 'Ручка «Дуб»', price: 380,  cat: 'stationery', img: 'https://basket-29.wbbasket.ru/vol5591/part559181/559181351/images/big/1.webp',
      images: [
           'https://basket-29.wbbasket.ru/vol5591/part559181/559181351/images/big/1.webp',
           'https://avatars.mds.yandex.net/i?id=2a00000179fb48be9d9221c420668c743e85-4283505-images-thumbs&n=13',
           'https://avatars.mds.yandex.net/get-mpic/16341179/2a00000199c8badc0b826433b314e9867cd6/orig',
           'https://cs2.livemaster.ru/storage/0c/0e/edb19e9b60ac86805405a00c92ta--kantselyarskie-tovary-sharikovaya-derevyannaya-ruchka-kanzler.jpg'] },
    { id: 30, title: 'Пенал «Таксы»', price: 690,  cat: 'stationery', img: 'https://storage.vsemayki.ru/images/0/4/4052/4052317/previews/people_4_pencil_case_front_white_500.jpg',
      images: [
           'https://storage.vsemayki.ru/images/0/4/4052/4052317/previews/people_4_pencil_case_front_white_500.jpg',
           'https://storage.vsemayki.ru/images/0/4/4052/4052317/previews/people_2_pencil_case_front_white_500.webp'] },
    { id: 31, title: 'Набор карандашей', price: 450,  cat: 'stationery', img: 'https://ir.ozone.ru/s3/multimedia-1-g/wc1000/20358499372.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-1-g/wc1000/20358499372.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-o/wc1000/20358489912.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-9/wc1000/20358498465.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-g/wc1000/20358490804.jpg'] },
    { id: 32, title: 'Ластик «Печенье»', price: 120,  cat: 'stationery', img: 'https://img-edg.joomcdn.net/11c9b44ed478f0965fead79c6f2e701accf02e18_1024_1024.jpeg',
      images: [
           'https://img-edg.joomcdn.net/11c9b44ed478f0965fead79c6f2e701accf02e18_1024_1024.jpeg',
           'https://img.joomcdn.net/29cdaa2bb3af898081a50a7ba656e0dad3e6f5b8_original.jpeg',
           'https://img-edg.joomcdn.net/82fb048b9a14dc1a7505a869ff26d68a00c2d49a_1024_1024.jpeg',
           'https://avatars.mds.yandex.net/i?id=ed81aab1c69793f3b5551ccab083ef8a_l-10767526-images-thumbs&n=13'],
      colors: [
        { name: 'Зелёный', hex: '#67E300' },
        { name: 'Розовый',  hex: '#E399CF' },
        { name: 'Сиреневый', hex: '#D48FE9' },
        { name: 'Коричневый', hex: '#653A16' },
        { name: 'Фиолетовый',  hex: '#7109AA' }
      ] },
    { id: 33, title: 'Стикеры', price: 220,  cat: 'stationery', img: 'https://avatars.mds.yandex.net/get-mpic/21028083/pic1bcac98c8926b01bb6c07e2dd78aa151/orig',
      images: [
           'https://avatars.mds.yandex.net/get-mpic/21028083/pic1bcac98c8926b01bb6c07e2dd78aa151/orig',
           'https://ir.ozone.ru/s3/multimedia-1-4/wc2500/9380221456.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-b/wc2500/12546580871.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-d/wc2500/8622292513.jpg'] },
    { id: 34, title: 'Игра «Лесной тропой»', price: 1900, cat: 'boardgames', img: 'https://avatars.mds.yandex.net/get-mpic/19754636/2a0000019d646410b3bdd9e1ba4b2475d82e/orig',
      images: [
           'https://avatars.mds.yandex.net/get-mpic/19754636/2a0000019d646410b3bdd9e1ba4b2475d82e/orig',
           'https://imo10.labirint.ru/books/763253/ph_01.jpg/484-0',
           'https://img.labirint.ru/images/comments_pic/2049/2_56fb5e57cdda8f5687766fe47da7b11f_1606996982.jpg',
           'https://avatars.mds.yandex.net/i?id=8725c9bf4c381fdb4862517ad208ec49_l-5296855-images-thumbs&n=13'] },
    { id: 35, title: 'Игра «Время кофе»', price: 2200, cat: 'boardgames', img: 'https://vsova.ru/upload/iblock/cea/rh5iz7d8decoqv2jv86c22yshl0lghge.jpg',
      images: [
           'https://vsova.ru/upload/iblock/cea/rh5iz7d8decoqv2jv86c22yshl0lghge.jpg',
           'https://www.mosigra.ru/image/cache/hobbygames_beta/data/tovari/zvezda/vremya-coffee/vremya-coffee3-1980x1980.webp',
           'https://www.mosigra.ru/image/cache/hobbygames_beta/data/tovari/zvezda/vremya-coffee/vremya-coffee5-1980x1980.webp',
           'https://images.firma-gamma.ru/images/b/1/d121785692604u_2.jpg'] },
    { id: 36, title: 'Пазл «Осень»', price: 850,  cat: 'boardgames', img: 'https://img.detmir.st/LejVGSrr8JLQKy_e1aAGrfa82UPe6-MZkPyCB4vkzcU/rs:fit:2100:2800/g:sm/ex:1/bg:FFFFFF/aHR0cHM6Ly9jYXRhbG9nLWNkbi5kZXRtaXIuc3QvbWVkaWEvWTdEMnljMjJhbFhQWEd5V3ZQV2dTOTBjUHUtQ0kzOTFGaVhsODMzWFdCMD0uanBlZw.webp',
      images: [
           'https://img.detmir.st/LejVGSrr8JLQKy_e1aAGrfa82UPe6-MZkPyCB4vkzcU/rs:fit:2100:2800/g:sm/ex:1/bg:FFFFFF/aHR0cHM6Ly9jYXRhbG9nLWNkbi5kZXRtaXIuc3QvbWVkaWEvWTdEMnljMjJhbFhQWEd5V3ZQV2dTOTBjUHUtQ0kzOTFGaVhsODMzWFdCMD0uanBlZw.webp',
           'https://avatars.mds.yandex.net/get-goods_pic/22029672/hatfd04f6f3a711b981dbb32a0d89d91367/orig',
           'https://avatars.mds.yandex.net/get-goods_pic/20241412/hat04f75b9829c55dc4bc696ad3a445dc10/orig',
           'https://avatars.mds.yandex.net/get-goods_pic/20814041/hatc4f22bc0a70f63792d2c0af6375bf35b/orig'] },
    { id: 37, title: 'Домино «Дерево»', price: 750,  cat: 'boardgames', img: 'https://pr-gifts.ru/upload/iblock/4fa/oxla9ta8g3v638v5o0g31rh7xmbcmod3/igra_domino_iz_massiva_buka.webp',
      images: [
           'https://pr-gifts.ru/upload/iblock/4fa/oxla9ta8g3v638v5o0g31rh7xmbcmod3/igra_domino_iz_massiva_buka.webp',
           'https://avatars.mds.yandex.net/i?id=692abdd699b54bd7a99915518f0694cc1947e0e9-4114739-images-thumbs&n=13',
           'https://colapsar.ru/upload/iblock/9c6/v2c0i8xxl2pbs1p9tihu2tr7aik4n37w.jpg',
           'https://colapsar.ru/upload/iblock/cb6/6mbi4qw419ef7g32c9beh3frfpmgyf3c.jpg'] },
    { id: 38, title: 'Шахматы «Классика»', price: 2400, cat: 'boardgames', img: 'https://ir.ozone.ru/s3/multimedia-g/wc1000/6163041100.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-g/wc1000/6163041100.jpg',
           'https://ir.ozone.ru/s3/multimedia-2/wc1000/6170190722.jpg',
           'https://ir.ozone.ru/s3/multimedia-7/wc1000/6120297319.jpg',
           'https://goods-photos.static1-sima-land.com/items/7076902/0/1600.jpg?v=1670479098'] },
    { id: 39, title: 'Свеча «Вереск»', price: 650,  cat: 'home', img: 'https://basket-47.wbbasket.ru/vol14515/part1451502/1451502059/images/big/1.webp',
      images: [
           'https://basket-47.wbbasket.ru/vol14515/part1451502/1451502059/images/big/1.webp',
           'https://avatars.mds.yandex.net/get-mpic/21053765/pica0e643fd45e3f0a08432f1007d95c132/optimize',
           'https://avatars.mds.yandex.net/get-mpic/21567637/pic8044375ac2c241c769d0d7b25876bd4e/optimize',
           'https://avatars.mds.yandex.net/get-mpic/18742739/pic188880ebca7cd7f568b61de8c900d461/optimize'] },
    { id: 40, title: 'Шкатулка «Малохитова»', price: 2400, cat: 'home', img: 'https://zlatprezent.ru/wa-data/public/shop/products/81/42/4281/images/21407/shkatulka-iz-malakhita-s-yasherkoy-iz-bronzy.970.webp',
      images: [
           'https://zlatprezent.ru/wa-data/public/shop/products/81/42/4281/images/21407/shkatulka-iz-malakhita-s-yasherkoy-iz-bronzy.970.webp',
           'https://zlatprezent.ru/wa-data/public/shop/products/81/42/4281/images/21408/shkatulka-iz-malakhita-s-yasherkoy-iz-bronzy-1.970.webp',
           'https://zlatprezent.ru/wa-data/public/shop/products/81/42/4281/images/21410/shkatulka-iz-malakhita-s-yasherkoy-iz-bronzy-3.970.webp',
           'https://zlatprezent.ru/wa-data/public/shop/products/81/42/4281/images/21409/shkatulka-iz-malakhita-s-yasherkoy-iz-bronzy-2.970.webp'] },
    { id: 41, title: 'Плед «Уют»', price: 3500, cat: 'home', img: 'https://cdn.lemanapro.ru/lmru/image/upload/v1677259558/lmcode/dHIEe7IW6UODCaLZQWmk5w/90893165.jpg',
      images: [
           'https://cdn.lemanapro.ru/lmru/image/upload/v1677259558/lmcode/dHIEe7IW6UODCaLZQWmk5w/90893165.jpg',
           'https://cdn.lemanapro.ru/lmru/image/upload/v1677259642/lmcode/uRVmbI1xiEypwcV7wwGJfg/90893160.jpg',
           'https://posudacenter.ru/upload/iblock/543/k1qqh9tqvblszslmgcfxfpi8onuzar86.jpg',
           'https://posudacenter.ru/upload/iblock/215/22u7a5yungxkbwr9we9bvoh3hyrslhf9.jpg'],
      colors: [
        { name: 'Коричневый', hex: '#653A16' },
        { name: 'Серый',  hex: '#808080' },
        { name: 'Розовый', hex: '#E399CF' },
        { name: 'Голубой', hex: '#72CBCB' } ] },
    { id: 42, title: 'Кружка «Ручной труд»', price: 890,  cat: 'home', img: '/img/kruzhka.jpg'},
    { id: 43, title: 'Кружка «Шины»', price: 890,  cat: 'home', img: 'https://magicmag.net/image/cachewebp/catalog/items9999-0000/ilikegift/xx/kruzka-shini-1398x1398.webp',
      images: [
           'https://magicmag.net/image/cachewebp/catalog/items9999-0000/ilikegift/xx/kruzka-shini-1398x1398.webp',
           'https://magicmag.net/image/cachewebp/catalog/items9999-0000/ilikegift/xx/kruzka-shini1-1398x1398.webp',
           'https://magicmag.net/image/cachewebp/catalog/items9999-0000/ilikegift/xx/kruzka-shini2-1398x1398.webp',
           'https://magicmag.net/image/cachewebp/catalog/items9999-0000/ilikegift/xx/kruzka-shini3-1398x1398.webp'] },
    { id: 44, title: 'Ваза «Керамика»', price: 1750, cat: 'home', img: 'https://avatars.mds.yandex.net/get-mpic/17699281/2a0000019be71e5f23816fd330f94d024bd2/optimize',
      images: [
           'https://avatars.mds.yandex.net/get-mpic/17699281/2a0000019be71e5f23816fd330f94d024bd2/optimize',
           'https://avatars.mds.yandex.net/get-mpic/16510834/2a0000019be71160d70b898eda4397c9407a/optimize',
           'https://avatars.mds.yandex.net/get-mpic/17919307/2a0000019be71160d675efe24c25159114ad/optimize',
           'https://avatars.mds.yandex.net/get-mpic/16146676/2a0000019be71160d6bb2e509739fcb99c25/optimize'] },
    { id: 45, title: 'Аромадиффузор «Лес после дождя»', price: 1100, cat: 'home', img: 'https://ir.ozone.ru/s3/multimedia-1-o/wc1000/7439222688.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-1-o/wc1000/7439222688.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-9/wc1000/7275395097.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-2/wc1000/7275395126.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-i/wc1000/7275395106.jpg'] },
    { id: 46, title: 'Фотоальбом «Море»', price: 1400, cat: 'photo', img: 'https://basket-17.wbbasket.ru/vol2699/part269960/269960910/images/big/1.webp',
      images: [
           'https://basket-17.wbbasket.ru/vol2699/part269960/269960910/images/big/1.webp',
           'https://basket-17.wbbasket.ru/vol2699/part269960/269960910/images/big/2.webp?picsUpdate=0',
           'https://basket-17.wbbasket.ru/vol2699/part269960/269960910/images/big/4.webp?picsUpdate=0',
           'https://basket-17.wbbasket.ru/vol2699/part269960/269960910/images/big/6.webp?picsUpdate=0'] },
    { id: 47, title: 'Фотоальбом «Моё детство»', price: 1600, cat: 'photo', img: 'https://cs2.livemaster.ru/storage/68/2e/668ecdeee7106100dbbce73f92kz--raboty-dlya-detej-fotoarhiv-moe-detstvo-na-200-fotografij-bir.jpg',
      images: [
           'https://cs2.livemaster.ru/storage/68/2e/668ecdeee7106100dbbce73f92kz--raboty-dlya-detej-fotoarhiv-moe-detstvo-na-200-fotografij-bir.jpg',
           'https://i.pinimg.com/736x/d3/a7/82/d3a782ce7b3fb9f8ab02d4fe61e06220.jpg',
           'https://i.pinimg.com/originals/89/2d/02/892d02912a49cd9017e6437fc5940790.jpg',
           'https://cs2.livemaster.ru/storage/68/2e/668ecdeee7106100dbbce73f92kz--raboty-dlya-detej-fotoarhiv-moe-detstvo-na-200-fotografij-bir.jpg'] },
    { id: 48, title: 'Фотоальбом «Свадьба»', price: 2100, cat: 'photo', img: 'https://www.yarkiy.ru/system/uploads/preview/photo_storage/344628/3bbn200-336s.jpg',
      images: [
           'https://www.yarkiy.ru/system/uploads/preview/photo_storage/344628/3bbn200-336s.jpg',
           'https://www.yarkiy.ru/system/uploads/preview/photo_storage/344629/7bbn200-336s.jpg',
           'https://www.yarkiy.ru/system/uploads/preview/photo_storage/344630/8bbn200-336s.jpg',
           'https://www.yarkiy.ru/system/uploads/preview/photo_storage/344633/4bbn200-336s.jpg'] },
    { id: 49, title: 'Фотоальбом «Только не»', price: 690,  cat: 'photo', img: 'https://basket-04.wbbasket.ru/vol707/part70719/70719372/images/big/1.webp',
      images: [
           'https://basket-04.wbbasket.ru/vol707/part70719/70719372/images/big/1.webp',
           'https://ekt-basket-cdn-11.geobasket.ru/vol707/part70719/70719372/images/big/5.webp?picsUpdate=0',
           'https://ekt-basket-cdn-11.geobasket.ru/vol707/part70719/70719372/images/big/6.webp?picsUpdate=0',
           'https://ekt-basket-cdn-11.geobasket.ru/vol707/part70719/70719372/images/big/8.webp?picsUpdate=0'] },
    { id: 50, title: 'Фоторамка «Семья»', price: 850,  cat: 'photo', img: 'https://ir.ozone.ru/s3/multimedia-1-r/wc1000/9632395719.jpg',
      images: [
           'https://ir.ozone.ru/s3/multimedia-1-r/wc1000/9632395719.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-z/wc1000/11880981503.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-1/wc1000/7453067833.jpg',
           'https://ir.ozone.ru/s3/multimedia-1-d/wc1000/11880985081.jpg'],
      colors: [
        { name: 'Чёрный', hex: '#000000' },
        { name: 'Белый',  hex: '#FFFFFF' } ] },
    { id: 51, title: 'Фотоальбом «Путешествие»', price: 1850, cat: 'photo', img: 'https://basket-12.wbbasket.ru/vol1743/part174314/174314818/images/big/1.webp',
      images: [
           'https://basket-12.wbbasket.ru/vol1743/part174314/174314818/images/big/1.webp',
           'https://ekt-basket-cdn-17.geobasket.ru/vol1743/part174314/174314818/images/big/3.webp?picsUpdate=0',
           'https://ekt-basket-cdn-17.geobasket.ru/vol1743/part174314/174314818/images/big/6.webp?picsUpdate=0',
           'https://ekt-basket-cdn-17.geobasket.ru/vol1743/part174314/174314818/images/big/7.webp?picsUpdate=0'] },
  ];

  /* ---------- Утилиты ---------- */
  const formatPrice = (n) => Number(n || 0).toLocaleString('ru-RU') + ' ₽';
  const getById = (id) => LIST.find(p => p.id === Number(id));
  const getCategory = (key) => CATEGORIES[key] || { name: key, icon: '📦' };
  const getDetails = (catKey) => CATEGORY_DETAILS[catKey] || { desc: '', specs: {} };

  const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));

  /* Возвращает 4 картинки для галереи */
  function getGalleryImages(product) {
    if (Array.isArray(product.images) && product.images.length > 0) {
      const arr = [...product.images];
      while (arr.length < 4) arr.push(product.img || arr[0]);
      return arr.slice(0, 4);
    }
    const base = product.img || '';
    const sep = base.includes('?') ? '&' : '?';
    return [
      base,
      `${base}${sep}v=2`,
      `${base}${sep}v=3`,
      `${base}${sep}v=4`
    ];
  }

  /* Цвета: возвращает массив {name, hex} или пустой массив */
  function getColors(product) {
    return Array.isArray(product.colors) ? product.colors : [];
  }

  /* ---------- Экспорт ---------- */
  global.Products = {
    CATEGORIES,
    CATEGORY_DETAILS,
    LIST,
    formatPrice,
    getById,
    getCategory,
    getDetails,
    escapeHtml,
    getGalleryImages,
    getColors
  };
})(window);