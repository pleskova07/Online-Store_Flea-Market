/* =============================================================
   static/js/common.js
   Общий JS для всех страниц «Барахолки»:
   тема, шапка, меню пользователя, logout, бургер, поиск,
   синхронизация между вкладками.
   Требует: /js/storage.js (глобальный объект Store).
   ============================================================= */

(function (global) {
  const API = '/api';

  /* ---------- Тема ---------- */
  // Применяем сохранённую тему как можно раньше (до отрисовки)
  (function applySavedTheme() {
    if (localStorage.getItem('theme') === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  })();

  function initTheme() {
    const btn = document.getElementById('themeToggle');
    const icon = document.getElementById('themeIcon');
    if (!btn) return;

    const update = () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      if (icon) icon.textContent = isDark ? '☀' : '🌙';
      btn.title = isDark ? 'Светлая тема' : 'Тёмная тема';
    };
    update();

    btn.addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      if (isDark) {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
      }
      update();
    });
  }

  /* ---------- Пользователь ---------- */
  function getUser() {
    try { return JSON.parse(localStorage.getItem('user') || 'null'); }
    catch { return null; }
  }

  function getInitials(name, surname) {
    const a = (name || '?')[0] || '?';
    const b = (surname || '')[0] || '';
    return (a + b).toUpperCase().slice(0, 2);
  }

  /* ---------- Обновление шапки: «Войти» или меню пользователя ---------- */
  function updateHeaderAuth() {
    const loginBtn = document.getElementById('headerLoginBtn');
    const userMenu = document.getElementById('userMenu');
    if (!loginBtn || !userMenu) return;

    const token = localStorage.getItem('authToken');
    const user = getUser();

    if (token && user) {
      loginBtn.style.display = 'none';
      userMenu.style.display = 'block';

      document.getElementById('userAvatar').textContent = getInitials(user.name, user.surname);
      document.getElementById('userName').textContent = user.name || 'Профиль';
      document.getElementById('userDropdownName').textContent =
        [user.surname, user.name, user.patronymic].filter(Boolean).join(' ') || 'Профиль';
      document.getElementById('userDropdownLogin').textContent = '@' + (user.username || '');
    } else {
      loginBtn.style.display = 'inline-flex';
      userMenu.style.display = 'none';
    }
  }

  /* ---------- Меню пользователя ---------- */
  function initUserMenu() {
    const menu = document.getElementById('userMenu');
    const btn = document.getElementById('userMenuBtn');
    if (!menu || !btn) return;

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = menu.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    document.addEventListener('click', (e) => {
      if (!menu.contains(e.target)) {
        menu.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        menu.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- Выход ---------- */
  // onAfter — необязательный колбэк, вызывается после выхода
  // (например, чтобы перерисовать страницу под гостя).
  function initLogout(onAfter) {
    document.querySelectorAll('[data-logout]').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('Выйти из аккаунта?')) return;

        const token = localStorage.getItem('authToken');
        try {
          await fetch(`${API}/auth/logout`, {
            method: 'POST',
            headers: token ? { 'X-Auth-Token': token } : {}
          });
        } catch (e) { /* ignore */ }

        localStorage.removeItem('authToken');
        localStorage.removeItem('user');

        updateHeaderAuth();
        if (typeof Store !== 'undefined') await Store.updateHeaderCounts();
        if (typeof onAfter === 'function') onAfter();
      });
    });
  }

  /* ---------- Бургер ---------- */
  function initBurger() {
    const b = document.querySelector('.header__burger');
    const n = document.querySelector('.header__nav');
    if (b && n) b.addEventListener('click', () => n.classList.toggle('is-open'));
  }

  /* ---------- Поиск в шапке ---------- */
  function initSearch() {
    const btn = document.querySelector('.header__search');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const q = prompt('Что ищем?');
      if (q && q.trim()) {
        location.href = `/catalog.html?q=${encodeURIComponent(q.trim())}`;
      }
    });
  }

  /* ---------- Синхронизация между вкладками ---------- */
  // onChange(key) — необязательный колбэк, вызывается при изменении
  // cart/fav/auth (чтобы страница перерисовала свои данные).
  function initStorageSync(onChange) {
    window.addEventListener('storage', async (e) => {
      if (['cartItems', 'cartCount', 'favItems', 'authToken', 'user'].includes(e.key)) {
        updateHeaderAuth();
        if (typeof Store !== 'undefined') await Store.updateHeaderCounts();
        if (typeof onChange === 'function') onChange(e.key);
      }
      if (e.key === 'theme') {
        const t = localStorage.getItem('theme');
        if (t === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
        else document.documentElement.removeAttribute('data-theme');
        const icon = document.getElementById('themeIcon');
        if (icon) icon.textContent = t === 'dark' ? '☀' : '🌙';
      }
    });
  }

  /* ---------- Главный init для всех страниц ---------- */
  // opts.onAfterLogout  — вызывается после выхода
  // opts.onStorageChange — вызывается при изменении cart/fav/auth
  async function initCommon(opts = {}) {
    initTheme();
    initUserMenu();
    initLogout(opts.onAfterLogout);
    initBurger();
    initSearch();
    updateHeaderAuth();

    if (typeof Store !== 'undefined') {
      await Store.updateHeaderCounts();
    }

    initStorageSync(opts.onStorageChange);
  }

  /* ---------- Экспорт ---------- */
  global.Common = {
    API,
    initCommon,
    initTheme,
    initUserMenu,
    initLogout,
    initBurger,
    initSearch,
    initStorageSync,
    updateHeaderAuth,
    getUser,
    getInitials
  };
})(window);